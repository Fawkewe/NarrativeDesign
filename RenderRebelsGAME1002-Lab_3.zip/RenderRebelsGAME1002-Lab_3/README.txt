sprites used with permission and within the license from Kenmi and Scissor Marks 
https://kenmi-art.itch.io
https://twitter.com/ScissorMarks