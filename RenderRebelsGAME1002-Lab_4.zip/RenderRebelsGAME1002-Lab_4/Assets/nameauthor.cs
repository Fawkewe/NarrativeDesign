using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nameauthor : MonoBehaviour
{
   public string title;
   public string author;
}
