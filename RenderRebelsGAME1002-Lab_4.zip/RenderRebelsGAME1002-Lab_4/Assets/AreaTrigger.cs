using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class AreaTrigger : MonoBehaviour
{
    public string title = "title ??";
    public string author = "by: ???";
}